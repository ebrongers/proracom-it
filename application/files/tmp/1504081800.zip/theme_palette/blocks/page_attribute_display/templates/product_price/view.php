<?php
defined('C5_EXECUTE') or die('Access Denied.'); ?>

<div class="product-page-attribute-display">
<p class="product-price">

<?php
echo $controller->getContent();
?>
</p>
</div>
